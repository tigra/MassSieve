java -Xss2m -Xms512m -Xmx1024m -jar MassSieve.jar
